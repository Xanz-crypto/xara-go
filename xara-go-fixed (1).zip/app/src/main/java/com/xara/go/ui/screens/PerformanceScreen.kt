package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.hardware.RamInfo
import com.xara.go.model.BackgroundApp
import com.xara.go.ui.theme.*

@Composable
fun PerformanceScreen(
    ramInfo: RamInfo,
    cpuFreq: String,
    currentFpsHz: Int,
    backgroundApps: List<BackgroundApp>,
    isCleaning: Boolean,
    lastCleanResult: String?,
    onCleanRam: () -> Unit,
    onForceStopApp: (BackgroundApp) -> Unit,
    onToggleWhitelist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Kartu Kiri: Metrik Real-time & Grafik RAM
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // 4 Kotak Metrik Atas
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricBox(title = "CPU", value = cpuFreq, modifier = Modifier.weight(1f))
                    MetricBox(title = "GPU", value = "N/A", modifier = Modifier.weight(1f))
                    MetricBox(title = "RAM", value = "${ramInfo.percentUsed}%", modifier = Modifier.weight(1f), isHighlighted = true)
                    MetricBox(title = "FPS", value = "$currentFpsHz Hz", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Area Grafik Visual Penggunaan RAM Real-time
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF090E17))
                        .border(1.dp, Color(0x22334155), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "PENGGUNAAN MEMORI SISTEM ASLI",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                        )

                        // Baris Visualisasi Batang RAM
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.Bottom
                        ) {
                            val history = listOf(58, 62, 60, 64, 63, 67, 65, 66, 62, ramInfo.percentUsed)
                            history.forEach { pct ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(pct / 100f)
                                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                        .background(if (pct == ramInfo.percentUsed) NeonCyan else Color(0xFF1E293B))
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("60 DTK", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text("SEKARANG", style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan))
                        }
                    }
                }
            }
        }

        // Kartu Kanan: Bersihkan RAM & Daftar Aplikasi Berat di Latar
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header Bersihkan RAM
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bersihkan RAM",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${ramInfo.percentUsed}%",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tombol Besar Bersihkan RAM
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isCleaning) Color(0xFF0284C7) else NeonCyan)
                        .clickable(enabled = !isCleaning) { onCleanRam() }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CleaningServices,
                            contentDescription = "Bersihkan RAM",
                            tint = DarkBgStart,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (isCleaning) "Membersihkan RAM..." else "Bersihkan RAM",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = DarkBgStart,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            )
                            Text(
                                text = "${ramInfo.formattedUsed} / ${ramInfo.formattedTotal} terpakai",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color(0xFF082F49),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }

                // Hasil Pembersihan Terakhir (Sebelum & Sesudah Angka Asli)
                if (lastCleanResult != null) {
                    Text(
                        text = lastCleanResult,
                        style = MaterialTheme.typography.bodyMedium.copy(color = SuccessGreen, fontSize = 11.sp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Header List Aplikasi Latar Belakang
                Text(
                    text = "APLIKASI BERAT DI LATAR",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                )

                // Daftar Aplikasi Latar Belakang
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(backgroundApps) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(PillInactive)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                // Ikon Daftar Putih
                                Icon(
                                    imageVector = if (app.isWhitelisted) Icons.Default.Shield else Icons.Outlined.Shield,
                                    contentDescription = "Daftar Putih",
                                    tint = if (app.isWhitelisted) SuccessGreen else TextMuted,
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clickable { onToggleWhitelist(app.packageName) }
                                )

                                Column {
                                    Text(
                                        text = app.appName,
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
                                        maxLines = 1
                                    )
                                    if (app.isWhitelisted) {
                                        Text(
                                            text = "Dilindungi (Whitelist)",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp, color = SuccessGreen)
                                        )
                                    }
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "${app.memoryUsageMb} MB",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 12.sp)
                                )

                                // Tombol Hentikan via am force-stop
                                if (!app.isWhitelisted) {
                                    Row(
                                        modifier = Modifier
                                            .border(1.dp, DangerRed.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { onForceStopApp(app) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Block,
                                            contentDescription = "Hentikan",
                                            tint = DangerRed,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = "Hentikan",
                                            style = MaterialTheme.typography.labelSmall.copy(color = DangerRed, fontSize = 10.sp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Text(
                    text = "ⓘ Game & aplikasi sistem penting otomatis dilindungi di daftar putih",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 10.sp),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun MetricBox(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    isHighlighted: Boolean = false
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isHighlighted) PillActive else PillInactive)
            .border(
                1.dp,
                if (isHighlighted) NeonCyan.copy(alpha = 0.5f) else Color.Transparent,
                RoundedCornerShape(12.dp)
            )
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (isHighlighted) NeonCyan else TextPrimary
                )
            )
        }
    }
}
