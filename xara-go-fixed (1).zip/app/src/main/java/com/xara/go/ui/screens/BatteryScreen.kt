package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EnergySavingsLeaf
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.hardware.BatteryInfo
import com.xara.go.ui.theme.*

@Composable
fun BatteryScreen(
    batteryInfo: BatteryInfo,
    isBatterySaverActive: Boolean,
    onToggleBatterySaver: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Kartu Kiri: Status Baterai & Pengukur Suhu Asli
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Baris Persentase Baterai
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BatteryFull,
                            contentDescription = "Baterai",
                            tint = NeonCyan,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = "${batteryInfo.percentage}%",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 32.sp
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "ESTIMASI SISA",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                        )
                        Text(
                            text = if (batteryInfo.isCharging) "Mengisi daya" else "${(batteryInfo.percentage * 4.5).toInt()} mnt",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 4 Kotak Metrik Baterai Asli
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricTile(title = "SUHU", value = "${String.format("%.1f", batteryInfo.temperatureC)}°C", color = SuccessGreen, modifier = Modifier.weight(1f))
                    MetricTile(title = "TEGANGAN", value = "${String.format("%.2f", batteryInfo.voltageV)} V", color = TextPrimary, modifier = Modifier.weight(1f))
                    MetricTile(
                        title = "ARUS KELUAR",
                        value = batteryInfo.currentNowMa?.let { "${it} mA" } ?: "Tidak didukung",
                        color = if ((batteryInfo.currentNowMa ?: 0) < 0) DangerRed else SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricTile(title = "KESEHATAN", value = batteryInfo.healthText, color = SuccessGreen, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Area Pengukur Suhu Baterai
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF090E17))
                        .border(1.dp, Color(0x22334155), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Thermostat,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "SUHU BATERAI • STATUS ASLI",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }
                            Text(
                                text = batteryInfo.thermalStatusText,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = if (batteryInfo.temperatureC >= 42f) DangerRed else SuccessGreen,
                                    fontSize = 12.sp
                                )
                            )
                        }

                        // Garis Gradien Bar Suhu (30° s/d 50°)
                        val tempClamped = batteryInfo.temperatureC.coerceIn(30f, 50f)
                        val progress = (tempClamped - 30f) / (50f - 30f)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(SuccessGreen, Color(0xFFFACC15), DangerRed)
                                    )
                                )
                        )

                        // Label Suhu 30°, 40°, 45°, 50°
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("30°", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text("40°", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFFACC15)))
                            Text("45°", style = MaterialTheme.typography.labelSmall.copy(color = DangerRed.copy(alpha = 0.8f)))
                            Text("50°", style = MaterialTheme.typography.labelSmall.copy(color = DangerRed))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("MULAI: ${String.format("%.1f", batteryInfo.temperatureC)}°", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text("RATA²: ${String.format("%.1f", batteryInfo.temperatureC)}°", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                            Text("MAKS: ${String.format("%.1f", batteryInfo.temperatureC)}°", style = MaterialTheme.typography.labelSmall.copy(color = TextPrimary))
                        }
                    }
                }
            }
        }

        // Kartu Kanan: Hemat Baterai & Fast Charge
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Kotak Hemat Baterai
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(PillInactive)
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EnergySavingsLeaf,
                                    contentDescription = null,
                                    tint = if (isBatterySaverActive) SuccessGreen else TextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column {
                                    Text(
                                        text = "Hemat Baterai",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = if (isBatterySaverActive) "Aktif (Refresh rate dibatasi & sync jeda)" else "Nonaktif",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 11.sp)
                                    )
                                }
                            }

                            Switch(
                                checked = isBatterySaverActive,
                                onCheckedChange = onToggleBatterySaver,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = DarkBgStart,
                                    checkedTrackColor = NeonCyan
                                )
                            )
                        }

                        Text(
                            text = "Turunkan kecerahan layar, batasi refresh rate ke 60Hz, dan jeda sinkronisasi latar belakang selama bermain.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 11.sp, color = TextSecondary)
                        )
                    }
                }

                // Kotak Fast Charge
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(PillInactive)
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (batteryInfo.isCharging) Color(0xFFFACC15) else TextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = "Fast Charge",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (batteryInfo.isCharging) "Sedang mengisi (${batteryInfo.chargingSourceText})" else "Tidak sedang mengisi",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 11.sp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0F172A))
                                    .padding(8.dp)
                            ) {
                                Column {
                                    Text("CHARGER", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                                    Text(
                                        batteryInfo.chargingSourceText,
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0F172A))
                                    .padding(8.dp)
                            ) {
                                Column {
                                    Text("PROTOKOL", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                                    Text(
                                        if (batteryInfo.isCharging) "USB-PD / QC" else "—",
                                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = "Colok charger untuk melihat arus dan status pengisian cepat sistem.",
                            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp, color = TextMuted)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricTile(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0F172A))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted, fontSize = 9.sp))
            Text(
                value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = color
                )
            )
        }
    }
}
