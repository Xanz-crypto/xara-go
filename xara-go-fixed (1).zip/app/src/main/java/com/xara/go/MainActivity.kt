package com.xara.go

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.xara.go.ai.PerformanceEngine
import com.xara.go.model.BackgroundApp
import com.xara.go.model.GameManager
import com.xara.go.model.InstalledGame
import com.xara.go.service.GamePanelOverlayService
import com.xara.go.service.GameWatcherService
import com.xara.go.ui.components.NavigationTab
import com.xara.go.ui.components.Sidebar
import com.xara.go.ui.components.TopHeader
import com.xara.go.ui.screens.*
import com.xara.go.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var gameManager: GameManager
    private val aiEngine = PerformanceEngine()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameManager = GameManager(this)

        // Mulai watcher service jika izin tersedia
        try {
            GameWatcherService.start(this)
        } catch (_: Exception) {}

        setContent {
            XaraGoTheme {
                val app = XaraGoApplication.instance
                val scope = rememberCoroutineScope()

                // State Asli Sistem
                val ramInfo by app.hardwareMonitor.ramState.collectAsState()
                val batteryInfo by app.hardwareMonitor.batteryState.collectAsState()
                val cpuFreq by app.hardwareMonitor.cpuFrequencyGhz.collectAsState()
                val pingMs by app.hardwareMonitor.pingMs.collectAsState()
                val privilegeState by app.shizukuManager.privilegeState.collectAsState()

                // State Layar & Navigasi
                var currentTab by remember { mutableStateOf(NavigationTab.GAME_SPACE) }
                var isTextureScreenOpen by remember { mutableStateOf(false) }
                var isPrivilegeGuideOpen by remember { mutableStateOf(false) }

                // State Game & Aplikasi
                var games by remember { mutableStateOf<List<InstalledGame>>(emptyList()) }
                var selectedGame by remember { mutableStateOf<InstalledGame?>(null) }
                var backgroundApps by remember { mutableStateOf<List<BackgroundApp>>(emptyList()) }

                // State Pengoptimalan & Tweak
                var isCleaningRam by remember { mutableStateOf(false) }
                var lastCleanResult by remember { mutableStateOf<String?>(null) }
                var selectedRefreshRate by remember { mutableStateOf(app.hardwareMonitor.hardwareSpecs.currentRefreshRate) }
                var colorSaturation by remember { mutableStateOf(1.0f) }
                var gameResolutionPct by remember { mutableStateOf(100) }
                var fpsLimit by remember { mutableStateOf(90) }
                var gameMode by remember { mutableStateOf("performance") }
                var isSustainedPerformance by remember { mutableStateOf(false) }
                var animScale by remember { mutableStateOf(0.5f) }
                var isBatterySaverActive by remember { mutableStateOf(false) }
                var isAutoEngineEnabled by remember { mutableStateOf(true) }

                // Load Data Awal
                LaunchedEffect(Unit) {
                    games = gameManager.getInstalledGames()
                    selectedGame = games.firstOrNull()
                    backgroundApps = gameManager.getRunningBackgroundApps()
                }

                // AI Engine Rule Evaluation
                val currentDecision = remember(batteryInfo, ramInfo, selectedGame) {
                    aiEngine.evaluateRules(
                        battery = batteryInfo,
                        ram = ramInfo,
                        supportedRefreshRates = app.hardwareMonitor.hardwareSpecs.supportedRefreshRates,
                        activeGamePackage = selectedGame?.packageName
                    )
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBgStart
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(DarkBgStart, DarkBgMid, DarkBgEnd)
                                )
                            )
                    ) {
                        // Sidebar Kiri (Navigasi Ikon Zayon Style)
                        Sidebar(
                            currentTab = currentTab,
                            onTabSelected = {
                                isTextureScreenOpen = false
                                currentTab = it
                            },
                            onOpenPrivilegeGuide = { isPrivilegeGuideOpen = true }
                        )

                        // Area Konten Utama Landscape
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        ) {
                            // Header Atas
                            TopHeader(
                                title = when {
                                    isTextureScreenOpen -> "Tekstur Ringan"
                                    currentTab == NavigationTab.GAME_SPACE -> "Pilih Game"
                                    currentTab == NavigationTab.PERFORMA -> "Performa"
                                    currentTab == NavigationTab.BATERAI -> "Baterai"
                                    currentTab == NavigationTab.GRAFIS -> "Grafis"
                                    else -> "Operasi AI"
                                },
                                batteryInfo = batteryInfo,
                                selectedGame = selectedGame,
                                games = games,
                                onSelectGame = { selectedGame = it },
                                onResetToDefault = {
                                    scope.launch {
                                        val restored = app.settingsBackup.restoreToDefault(app.shizukuManager)
                                        if (restored) {
                                            selectedRefreshRate = app.hardwareMonitor.hardwareSpecs.currentRefreshRate
                                            animScale = 1.0f
                                            gameMode = "standard"
                                            Toast.makeText(this@MainActivity, "Semua pengaturan dikembalikan ke bawaan pabrik", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                showGameSelector = !isTextureScreenOpen
                            )

                            // Tampilan Halaman Sesuai Tab
                            Box(modifier = Modifier.weight(1f)) {
                                if (isTextureScreenOpen) {
                                    TextureScreen(
                                        selectedGame = selectedGame,
                                        onBack = { isTextureScreenOpen = false },
                                        onSaveTextureConfig = {
                                            Toast.makeText(this@MainActivity, "Setelan Tekstur Ringan Disimpan", Toast.LENGTH_SHORT).show()
                                            isTextureScreenOpen = false
                                        }
                                    )
                                } else {
                                    when (currentTab) {
                                        NavigationTab.GAME_SPACE -> {
                                            GameSpaceScreen(
                                                games = games,
                                                selectedGame = selectedGame,
                                                onSelectGame = { selectedGame = it },
                                                batteryInfo = batteryInfo,
                                                ramInfo = ramInfo,
                                                cpuFreq = cpuFreq,
                                                pingMs = pingMs,
                                                onOpenTexture = { isTextureScreenOpen = true },
                                                onLaunchGame = { game ->
                                                    scope.launch {
                                                        // 1. Bersihkan RAM & aplikasi background secara otomatis
                                                        val killed = gameManager.autoCleanForGameLaunch(app.shizukuManager)
                                                        app.hardwareMonitor.performRealRamClean()

                                                        // 2. Minta izin overlay jika belum
                                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                                                            val intent = Intent(
                                                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                                Uri.parse("package:$packageName")
                                                            )
                                                            startActivity(intent)
                                                        } else {
                                                            GamePanelOverlayService.start(this@MainActivity)
                                                        }

                                                        // 3. Luncurkan game
                                                        gameManager.launchGame(game.packageName)
                                                    }
                                                }
                                            )
                                        }

                                        NavigationTab.PERFORMA -> {
                                            PerformanceScreen(
                                                ramInfo = ramInfo,
                                                cpuFreq = cpuFreq,
                                                currentFpsHz = selectedRefreshRate,
                                                backgroundApps = backgroundApps,
                                                isCleaning = isCleaningRam,
                                                lastCleanResult = lastCleanResult,
                                                onCleanRam = {
                                                    scope.launch {
                                                        isCleaningRam = true
                                                        val (before, after) = app.hardwareMonitor.performRealRamClean()
                                                        val freedBytes = (before.usedBytes - after.usedBytes).coerceAtLeast(0)
                                                        val freedMb = freedBytes / (1024 * 1024)
                                                        lastCleanResult = "✓ Berhasil membebaskan ${freedMb} MB RAM asli (${before.formattedUsed} -> ${after.formattedUsed})"
                                                        backgroundApps = gameManager.getRunningBackgroundApps()
                                                        isCleaningRam = false
                                                    }
                                                },
                                                onForceStopApp = { appItem ->
                                                    scope.launch {
                                                        val res = app.shizukuManager.forceStopApp(appItem.packageName)
                                                        if (res.success) {
                                                            Toast.makeText(this@MainActivity, "Berhasil menghentikan ${appItem.appName}", Toast.LENGTH_SHORT).show()
                                                        } else {
                                                            Toast.makeText(this@MainActivity, res.error ?: "Gagal menghentikan (Butuh Shizuku/root)", Toast.LENGTH_LONG).show()
                                                        }
                                                        backgroundApps = gameManager.getRunningBackgroundApps()
                                                    }
                                                },
                                                onToggleWhitelist = { pkg ->
                                                    gameManager.toggleWhitelist(pkg)
                                                    scope.launch {
                                                        backgroundApps = gameManager.getRunningBackgroundApps()
                                                    }
                                                }
                                            )
                                        }

                                        NavigationTab.BATERAI -> {
                                            BatteryScreen(
                                                batteryInfo = batteryInfo,
                                                isBatterySaverActive = isBatterySaverActive,
                                                onToggleBatterySaver = { active ->
                                                    isBatterySaverActive = active
                                                    scope.launch {
                                                        if (active) {
                                                            app.shizukuManager.setRefreshRate(60f)
                                                        } else {
                                                            app.shizukuManager.setRefreshRate(selectedRefreshRate.toFloat())
                                                        }
                                                    }
                                                }
                                            )
                                        }

                                        NavigationTab.GRAFIS -> {
                                            GraphicsScreen(
                                                hardwareSpecs = app.hardwareMonitor.hardwareSpecs,
                                                selectedRefreshRate = selectedRefreshRate,
                                                onSelectRefreshRate = { rate ->
                                                    selectedRefreshRate = rate
                                                    scope.launch {
                                                        val res = app.shizukuManager.setRefreshRate(rate.toFloat())
                                                        if (!res.success) {
                                                            Toast.makeText(this@MainActivity, "Gagal mengunci refresh rate: ${res.error}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                colorSaturation = colorSaturation,
                                                onChangeSaturation = { colorSaturation = it },
                                                gameResolutionPct = gameResolutionPct,
                                                onChangeResolution = { res ->
                                                    gameResolutionPct = res
                                                    selectedGame?.let { game ->
                                                        scope.launch {
                                                            val scale = res / 100f
                                                            app.shizukuManager.setGameDownscale(game.packageName, scale)
                                                        }
                                                    }
                                                },
                                                fpsLimit = fpsLimit,
                                                onSelectFpsLimit = { fpsLimit = it },
                                                gameMode = gameMode,
                                                onSelectGameMode = { mode ->
                                                    gameMode = mode
                                                    selectedGame?.let { game ->
                                                        scope.launch {
                                                            val res = app.shizukuManager.setGameMode(game.packageName, mode)
                                                            if (!res.success) {
                                                                Toast.makeText(this@MainActivity, "Gagal mengatur Game Mode: ${res.error}", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    }
                                                },
                                                isSustainedPerformance = isSustainedPerformance,
                                                onToggleSustained = { isSustainedPerformance = it },
                                                animScale = animScale,
                                                onSelectAnimScale = { scale ->
                                                    animScale = scale
                                                    scope.launch {
                                                        val res = app.shizukuManager.setAnimationScales(scale)
                                                        if (!res.success) {
                                                            Toast.makeText(this@MainActivity, "Gagal mengubah animasi: ${res.error}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            )
                                        }

                                        NavigationTab.AI_PERFORMA -> {
                                            AiPerformanceScreen(
                                                batteryInfo = batteryInfo,
                                                ramInfo = ramInfo,
                                                currentDecision = currentDecision,
                                                isAutoEngineEnabled = isAutoEngineEnabled,
                                                onToggleAutoEngine = { isAutoEngineEnabled = it },
                                                onApplyNow = {
                                                    scope.launch {
                                                        aiEngine.applyDecision(
                                                            decision = currentDecision,
                                                            shizukuManager = app.shizukuManager,
                                                            gamePackage = selectedGame?.packageName
                                                        )
                                                        Toast.makeText(this@MainActivity, "Profil ${currentDecision.profile.displayName} berhasil diterapkan!", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Dialog Panduan & Status Shizuku
                    if (isPrivilegeGuideOpen) {
                        ShizukuGuideDialog(
                            privilegeState = privilegeState,
                            onRequestPermission = {
                                app.shizukuManager.requestShizukuPermission()
                            },
                            onDismiss = { isPrivilegeGuideOpen = false }
                        )
                    }
                }
            }
        }
    }
}
