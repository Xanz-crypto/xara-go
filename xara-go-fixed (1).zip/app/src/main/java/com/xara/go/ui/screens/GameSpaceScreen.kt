package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Texture
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.hardware.BatteryInfo
import com.xara.go.hardware.RamInfo
import com.xara.go.model.InstalledGame
import com.xara.go.ui.theme.*

@Composable
fun GameSpaceScreen(
    games: List<InstalledGame>,
    selectedGame: InstalledGame?,
    onSelectGame: (InstalledGame) -> Unit,
    batteryInfo: BatteryInfo,
    ramInfo: RamInfo,
    cpuFreq: String,
    pingMs: Int?,
    onOpenTexture: () -> Unit,
    onLaunchGame: (InstalledGame) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Baris Kartu Game Horizontal
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(games) { game ->
                val isSelected = game.packageName == selectedGame?.packageName

                Box(
                    modifier = Modifier
                        .width(280.dp)
                        .height(170.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    if (isSelected) Color(0xFF1E293B) else Color(0xFF111827),
                                    Color(0xFF0B0F19)
                                )
                            )
                        )
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) NeonCyan else Color(0x33334155),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { onSelectGame(game) }
                        .padding(14.dp)
                ) {
                    // Badge MODE KUSTOM di pojok kiri atas
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x990F172A))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "MODE",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = TextMuted)
                        )
                        Text(
                            text = "KUSTOM",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = NeonCyan)
                        )
                        Icon(
                            imageVector = Icons.Default.GridView,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(10.dp)
                        )
                    }

                    // Tanda Centang jika terpilih di pojok kanan atas
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(NeonCyan),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Terpilih",
                                tint = DarkBgStart,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Informasi Game di bagian bawah kartu
                    Column(
                        modifier = Modifier.align(Alignment.BottomStart)
                    ) {
                        Text(
                            text = game.appName,
                            style = MaterialTheme.typography.titleLarge.copy(fontSize = 17.sp),
                            maxLines = 1
                        )
                        val hours = game.playedTimeMinutes / 60
                        val mins = game.playedTimeMinutes % 60
                        Text(
                            text = "${hours}j ${mins}m",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 12.sp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bar Status Bawah (Hardware Asli + Tombol Mainkan)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceCard)
                .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Metrik-metrik Asli Sistem
            Row(
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // SUHU
                Column {
                    Text("SUHU", style = MaterialTheme.typography.labelSmall)
                    Text(
                        "${String.format("%.1f", batteryInfo.temperatureC)}°C",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // CPU
                Column {
                    Text("CPU", style = MaterialTheme.typography.labelSmall)
                    Text(
                        cpuFreq,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // PING
                Column {
                    Text("PING", style = MaterialTheme.typography.labelSmall)
                    Text(
                        pingMs?.let { "${it} ms" } ?: "-- ms",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // PERFORMA (Kombinasi AI Score)
                Column {
                    Text("PERFORMA", style = MaterialTheme.typography.labelSmall)
                    Text(
                        "${100 + (100 - ramInfo.percentUsed) / 2}%",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan
                        )
                    )
                }

                // BATERAI
                Column {
                    Text("BATERAI", style = MaterialTheme.typography.labelSmall)
                    Text(
                        "${batteryInfo.percentage}%",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            // Tombol Aksi Kanan: Tekstur Ringan + Mainkan Game
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Tombol Tekstur Ringan
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(PillInactive)
                        .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(16.dp))
                        .clickable { onOpenTexture() }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Texture,
                        contentDescription = "Tekstur Ringan",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Tekstur Ringan",
                        style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                    )
                }

                // Tombol Mainkan Game (Cyan Neon)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(NeonCyan)
                        .clickable { selectedGame?.let { onLaunchGame(it) } }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Mainkan",
                        tint = DarkBgStart,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = selectedGame?.appName ?: "Mainkan",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = DarkBgStart,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    )
                }
            }
        }
    }
}
