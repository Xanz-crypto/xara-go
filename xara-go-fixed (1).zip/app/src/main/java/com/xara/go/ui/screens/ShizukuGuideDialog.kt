package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.xara.go.shizuku.PrivilegeState
import com.xara.go.ui.theme.*

@Composable
fun ShizukuGuideDialog(
    privilegeState: PrivilegeState,
    onRequestPermission: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF0A0F1D))
                .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header Dialog
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "STATUS HAK AKSES SISTEM",
                            style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan, letterSpacing = 1.sp)
                        )
                        Text(
                            text = "Shizuku & Akses Root",
                            style = MaterialTheme.typography.headlineMedium.copy(fontSize = 18.sp)
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Kartu Status Nyata
                val (statusTitle, statusDesc, statusColor, isReady) = when (privilegeState) {
                    is PrivilegeState.Active -> when (privilegeState.mode) {
                        PrivilegeState.Active.Mode.SHIZUKU -> Quadruple("Shizuku Aktif (Privileged API)", "Semua fitur pengoptimalan sistem (Force-stop, Game Mode, Refresh Rate, Animasi) siap digunakan.", SuccessGreen, true)
                        PrivilegeState.Active.Mode.ROOT -> Quadruple("Akses Root Aktif (su)", "Izin root terdeteksi dan aktif untuk mengeksekusi perintah shell tingkat tinggi.", SuccessGreen, true)
                    }
                    is PrivilegeState.NotAuthorized -> Quadruple("Izin Shizuku Belum Diberikan", privilegeState.reason, WarningYellow, false)
                    PrivilegeState.Unavailable -> Quadruple("Shizuku Belum Berjalan & Root Tidak Ada", "Layanan Shizuku belum dijalankan pada perangkat ini. Ikuti panduan di bawah.", DangerRed, false)
                    PrivilegeState.Checking -> Quadruple("Memeriksa Layanan...", "Mendeteksi ketersediaan Shizuku Binder dan Superuser binary.", TextSecondary, false)
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(statusColor.copy(alpha = 0.12f))
                        .border(1.dp, statusColor.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (isReady) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(statusTitle, style = MaterialTheme.typography.titleMedium.copy(color = statusColor, fontSize = 13.sp, fontWeight = FontWeight.Bold))
                            Text(statusDesc, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 11.sp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Panduan Cara Menjalankan Shizuku Tanpa PC
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("PANDUAN AKTIVASI SHIZUKU (TANPA ROOT / TANPA PC):", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))

                    StepItem(step = "1", title = "Pasang Aplikasi Shizuku", desc = "Unduh aplikasi Shizuku dari Google Play Store atau GitHub Rikka.")
                    StepItem(step = "2", title = "Buka Opsi Pengembang (Developer Options)", desc = "Aktifkan 'Debugging Nirkabel' (Wireless Debugging) dan hubungkan ke Wi-Fi.")
                    StepItem(step = "3", title = "Pasangkan Perangkat (Pairing)", desc = "Buka Shizuku -> Pilih 'Mulai lewat Wireless Debugging' -> Masukkan kode pairing.")
                    StepItem(step = "4", title = "Beri Izin Xara Go", desc = "Buka Shizuku -> 'Aplikasi yang diizinkan' -> Centang Xara Go.")
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Kotak Perintah ADB Terminal Alternatif
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ATAU VIA ADB PC (TERMINAL):", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF050811))
                            .border(1.dp, Color(0x33334155), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = NeonCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tombol Minta Izin jika Shizuku terpasang
                if (!isReady) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NeonCyan)
                            .clickable { onRequestPermission() }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Minta Izin Shizuku Sekarang",
                            style = MaterialTheme.typography.titleMedium.copy(color = DarkBgStart, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StepItem(step: String, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(PillActive),
            contentAlignment = Alignment.Center
        ) {
            Text(step, style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan, fontSize = 10.sp))
        }
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp, fontWeight = FontWeight.SemiBold))
            Text(desc, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 10.sp))
        }
    }
}

data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
