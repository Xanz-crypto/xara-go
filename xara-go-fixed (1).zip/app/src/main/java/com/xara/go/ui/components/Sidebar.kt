package com.xara.go.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.ui.theme.*

enum class NavigationTab(val label: String, val icon: ImageVector) {
    GAME_SPACE("Game Space", Icons.Default.SportsEsports),
    PERFORMA("Performa", Icons.Default.Speed),
    BATERAI("Baterai", Icons.Default.BatteryChargingFull),
    GRAFIS("Grafis", Icons.Default.Tune),
    AI_PERFORMA("AI Engine", Icons.Default.Memory)
}

@Composable
fun Sidebar(
    currentTab: NavigationTab,
    onTabSelected: (NavigationTab) -> Unit,
    onOpenPrivilegeGuide: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(80.dp)
            .fillMaxHeight()
            .background(DarkBgStart)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Logo Xara Go (Lingkaran bernuansa neon)
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "X",
                color = NeonCyan,
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 20.sp)
            )
        }

        // Daftar Tab Navigasi Ikon
        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NavigationTab.values().forEach { tab ->
                val isSelected = tab == currentTab

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.height(48.dp)
                ) {
                    // Indikator Garis Neon Vertikal di tepi kiri tab aktif
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .width(4.dp)
                                .height(24.dp)
                                .clip(RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                                .background(NeonCyan)
                        )
                    } else {
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Kotak Ikon Tab
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) PillActive else Color.Transparent)
                            .clickable { onTabSelected(tab) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.label,
                            tint = if (isSelected) NeonCyan else TextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Tombol Privilese / Shizuku di bagian bawah
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(PillInactive)
                .clickable { onOpenPrivilegeGuide() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = "Status Izin Shizuku / Root",
                tint = TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
