package com.xara.go.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.hardware.BatteryInfo
import com.xara.go.model.InstalledGame
import com.xara.go.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun TopHeader(
    title: String,
    batteryInfo: BatteryInfo,
    selectedGame: InstalledGame?,
    games: List<InstalledGame>,
    onSelectGame: (InstalledGame) -> Unit,
    onResetToDefault: () -> Unit,
    showGameSelector: Boolean = true,
    modifier: Modifier = Modifier
) {
    var isDropdownOpen by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        while (true) {
            currentTime = sdf.format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Kolom Kiri: Judul Halaman
        Column {
            Text(
                text = "XARA GAME SPACE",
                style = MaterialTheme.typography.labelSmall.copy(
                    letterSpacing = 2.sp,
                    color = NeonCyan.copy(alpha = 0.8f)
                )
            )
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium.copy(fontSize = 20.sp)
            )
        }

        // Bar Kanan: Game selector, Reset button, Temperature badge, Clock
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Dropdown Pilihan Game (jika ditampilkan)
            if (showGameSelector && selectedGame != null) {
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(PillInactive)
                            .clickable { isDropdownOpen = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column {
                            Text(
                                text = selectedGame.appName,
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                            )
                            Text(
                                text = "Setelan per game",
                                style = MaterialTheme.typography.bodyMedium.copy(fontSize = 10.sp, color = TextMuted)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.KeyboardArrowDown,
                            contentDescription = "Pilih Game",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = isDropdownOpen,
                        onDismissRequest = { isDropdownOpen = false },
                        modifier = Modifier.background(SurfaceCard)
                    ) {
                        games.forEach { game ->
                            DropdownMenuItem(
                                text = { Text(game.appName, color = TextPrimary) },
                                onClick = {
                                    onSelectGame(game)
                                    isDropdownOpen = false
                                }
                            )
                        }
                    }
                }
            }

            // Tombol Reset ke Bawaan
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(PillInactive)
                    .clickable { onResetToDefault() }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.RestartAlt,
                    contentDescription = "Reset ke Bawaan",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Reset ke bawaan",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary, fontSize = 12.sp)
                )
            }

            // Pill Suhu Nyata
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(PillInactive)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Thermostat,
                    contentDescription = "Suhu HP",
                    tint = if (batteryInfo.temperatureC >= 42f) DangerRed else SuccessGreen,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "${String.format(Locale.US, "%.0f", batteryInfo.temperatureC)}°C",
                    style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp)
                )
                Text(
                    text = batteryInfo.thermalStatusText,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 11.sp,
                        color = if (batteryInfo.temperatureC >= 42f) DangerRed else SuccessGreen
                    )
                )
            }

            // Jam Digital
            Text(
                text = currentTime,
                style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp, color = TextPrimary)
            )
        }
    }
}
