package com.xara.go.shizuku

import android.content.Context
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

sealed class PrivilegeState {
    data object Checking : PrivilegeState()
    data class Active(val mode: Mode) : PrivilegeState() {
        enum class Mode { SHIZUKU, ROOT }
    }
    data class NotAuthorized(val reason: String) : PrivilegeState()
    data object Unavailable : PrivilegeState()
}

data class ShellResult(
    val success: Boolean,
    val output: String,
    val error: String? = null
)

class ShizukuManager(private val context: Context) {

    private val _privilegeState = MutableStateFlow<PrivilegeState>(PrivilegeState.Checking)
    val privilegeState: StateFlow<PrivilegeState> = _privilegeState

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkPrivilegeStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        checkPrivilegeStatus()
    }

    private val requestPermissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE_SHIZUKU) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                _privilegeState.value = PrivilegeState.Active(PrivilegeState.Active.Mode.SHIZUKU)
            } else {
                _privilegeState.value = PrivilegeState.NotAuthorized("Izin Shizuku ditolak pengguna")
            }
        }
    }

    fun init() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
        } catch (e: Throwable) {
            // Shizuku provider not ready or classloader error
        }
        checkPrivilegeStatus()
    }

    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        } catch (_: Throwable) {}
    }

    fun checkPrivilegeStatus() {
        if (isShizukuAvailable()) {
            if (hasShizukuPermission()) {
                _privilegeState.value = PrivilegeState.Active(PrivilegeState.Active.Mode.SHIZUKU)
                return
            } else {
                _privilegeState.value = PrivilegeState.NotAuthorized("Izin Shizuku belum diberikan")
                return
            }
        }

        // Cek fallback Root
        if (checkRootAvailable()) {
            _privilegeState.value = PrivilegeState.Active(PrivilegeState.Active.Mode.ROOT)
            return
        }

        _privilegeState.value = PrivilegeState.Unavailable
    }

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasShizukuPermission(): Boolean {
        return try {
            if (!isShizukuAvailable()) return false
            if (Shizuku.isPreV11()) false
            else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestShizukuPermission() {
        try {
            if (!isShizukuAvailable()) return
            if (!Shizuku.isPreV11()) Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun checkRootAvailable(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/su",
            "/system/bin/.ext/.su"
        )
        for (path in paths) {
            if (File(path).exists()) return true
        }
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("which", "su"))
            process.waitFor() == 0
        } catch (e: Throwable) {
            false
        }
    }

    suspend fun executeCommand(command: String): ShellResult = withContext(Dispatchers.IO) {
        if (isShizukuAvailable() && hasShizukuPermission()) {
            return@withContext executeViaShizuku(command)
        }

        if (checkRootAvailable()) {
            return@withContext executeViaRoot(command)
        }

        ShellResult(
            success = false,
            output = "",
            error = "Shizuku atau Root belum aktif. Perintah membutuhkan izin istimewa sistem."
        )
    }

    private fun executeViaShizuku(command: String): ShellResult {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errReader = BufferedReader(InputStreamReader(process.errorStream))

            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            while (errReader.readLine().also { line = it } != null) {
                error.append(line).append("\n")
            }

            val exitCode = process.waitFor()
            ShellResult(
                success = exitCode == 0,
                output = output.toString().trim(),
                error = if (exitCode != 0) error.toString().trim().ifEmpty { "Exit code: $exitCode" } else null
            )
        } catch (e: Throwable) {
            ShellResult(success = false, output = "", error = e.localizedMessage ?: "Gagal mengeksekusi via Shizuku")
        }
    }

    private fun executeViaRoot(command: String): ShellResult {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errReader = BufferedReader(InputStreamReader(process.errorStream))

            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.append(line).append("\n")
            }
            while (errReader.readLine().also { line = it } != null) {
                error.append(line).append("\n")
            }

            val exitCode = process.waitFor()
            ShellResult(
                success = exitCode == 0,
                output = output.toString().trim(),
                error = if (exitCode != 0) error.toString().trim().ifEmpty { "Exit code: $exitCode" } else null
            )
        } catch (e: Throwable) {
            ShellResult(success = false, output = "", error = e.localizedMessage ?: "Gagal mengeksekusi via Root")
        }
    }

    // Helper: Force Stop App latar belakang
    suspend fun forceStopApp(packageName: String): ShellResult {
        return executeCommand("am force-stop $packageName")
    }

    // Helper: Set Android Game Mode (Android 12+)
    suspend fun setGameMode(packageName: String, mode: String): ShellResult {
        // mode: standard, performance, battery
        return executeCommand("cmd game mode $mode $packageName")
    }

    // Helper: Set Refresh Rate
    suspend fun setRefreshRate(fps: Float): ShellResult {
        val peakCmd = "settings put system peak_refresh_rate $fps"
        val minCmd = "settings put system min_refresh_rate $fps"
        val res1 = executeCommand(peakCmd)
        val res2 = executeCommand(minCmd)
        return ShellResult(
            success = res1.success && res2.success,
            output = "${res1.output}\n${res2.output}".trim(),
            error = res1.error ?: res2.error
        )
    }

    // Helper: Atur Skala Animasi Sistem
    suspend fun setAnimationScales(scale: Float): ShellResult {
        val cmd = "settings put global window_animation_scale $scale && " +
                  "settings put global transition_animation_scale $scale && " +
                  "settings put global animator_duration_scale $scale"
        return executeCommand(cmd)
    }

    // Helper: Set Custom Downscale Resolusi Game (Android 13+)
    suspend fun setGameDownscale(packageName: String, scale: Float): ShellResult {
        return executeCommand("cmd game mode custom --downscale $scale $packageName")
    }

    companion object {
        const val REQUEST_CODE_SHIZUKU = 9001
    }
}
