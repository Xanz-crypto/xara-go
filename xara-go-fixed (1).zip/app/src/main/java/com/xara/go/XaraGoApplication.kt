package com.xara.go

import android.app.Application
import com.xara.go.hardware.HardwareMonitor
import com.xara.go.hardware.SystemSettingsBackup
import com.xara.go.shizuku.ShizukuManager

class XaraGoApplication : Application() {

    companion object {
        lateinit var instance: XaraGoApplication
            private set
    }

    lateinit var shizukuManager: ShizukuManager
        private set

    lateinit var hardwareMonitor: HardwareMonitor
        private set

    lateinit var settingsBackup: SystemSettingsBackup
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        shizukuManager = ShizukuManager(this)
        shizukuManager.init()

        hardwareMonitor = HardwareMonitor(this)
        settingsBackup = SystemSettingsBackup(this)

        // Simpan cadangan awal pengaturan sistem jika belum pernah disimpan
        settingsBackup.backupDefaultsIfNeeded()
    }

    override fun onTerminate() {
        super.onTerminate()
        shizukuManager.destroy()
    }
}
