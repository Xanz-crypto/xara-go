package com.xara.go.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.xara.go.R
import com.xara.go.XaraGoApplication
import com.xara.go.ui.overlay.GamePanelHUD
import com.xara.go.ui.theme.XaraGoTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class GamePanelOverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private lateinit var windowManager: WindowManager
    private var floatingBubbleView: View? = null
    private var hudOverlayView: View? = null

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val appViewModelStore = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = appViewModelStore
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundServiceNotification()
        showFloatingBubble()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "xara_overlay_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Xara Go Game Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Layanan overlay panel game melayang Xara Go"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Xara Game Panel Aktif")
            .setContentText("Ketuk gelembung di tepi layar untuk membuka kontrol game.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun showFloatingBubble() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 200
        }

        val bubbleComposeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GamePanelOverlayService)
            setViewTreeViewModelStoreOwner(this@GamePanelOverlayService)
            setViewTreeSavedStateRegistryOwner(this@GamePanelOverlayService)

            setContent {
                XaraGoTheme {
                    androidx.compose.foundation.layout.Box(
                        modifier = androidx.compose.ui.Modifier
                            .androidx.compose.foundation.layout.size(46.dp)
                            .androidx.compose.ui.draw.clip(androidx.compose.foundation.shape.CircleShape)
                            .androidx.compose.foundation.background(com.xara.go.ui.theme.DarkBgStart)
                            .androidx.compose.foundation.border(2.dp, com.xara.go.ui.theme.NeonCyan, androidx.compose.foundation.shape.CircleShape),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        androidx.compose.material3.Text(
                            text = "X",
                            color = com.xara.go.ui.theme.NeonCyan,
                            style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        bubbleComposeView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = true

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                event ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(bubbleComposeView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            toggleFullHud()
                        }
                        return true
                    }
                }
                return false
            }
        })

        floatingBubbleView = bubbleComposeView
        windowManager.addView(bubbleComposeView, params)
    }

    private fun toggleFullHud() {
        if (hudOverlayView != null) {
            hideFullHud()
        } else {
            showFullHud()
        }
    }

    private fun showFullHud() {
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val app = XaraGoApplication.instance
        val hudComposeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GamePanelOverlayService)
            setViewTreeViewModelStoreOwner(this@GamePanelOverlayService)
            setViewTreeSavedStateRegistryOwner(this@GamePanelOverlayService)

            setContent {
                val battery by app.hardwareMonitor.batteryState.collectAsState()
                val ram by app.hardwareMonitor.ramState.collectAsState()

                XaraGoTheme {
                    GamePanelHUD(
                        batteryInfo = battery,
                        ramInfo = ram,
                        cpuUsagePct = 35,
                        currentFps = 60,
                        onCleanRam = {
                            serviceScope.launch {
                                app.hardwareMonitor.performRealRamClean()
                            }
                        },
                        onToggleTurbo = {
                            serviceScope.launch {
                                app.shizukuManager.setAnimationScales(0.0f)
                            }
                        },
                        onToggleDnd = {
                            // Aktifkan mode Jangan Ganggu (DND)
                        },
                        onTakeScreenshot = {
                            serviceScope.launch {
                                app.shizukuManager.executeCommand("screencap -p /sdcard/xara_game_shot.png")
                            }
                        },
                        onCloseHud = {
                            hideFullHud()
                        }
                    )
                }
            }
        }

        hudOverlayView = hudComposeView
        windowManager.addView(hudComposeView, params)
    }

    private fun hideFullHud() {
        hudOverlayView?.let {
            windowManager.removeView(it)
            hudOverlayView = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        floatingBubbleView?.let { windowManager.removeView(it) }
        hudOverlayView?.let { windowManager.removeView(it) }
    }

    companion object {
        private const val NOTIFICATION_ID = 2001

        fun start(context: Context) {
            val intent = Intent(context, GamePanelOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, GamePanelOverlayService::class.java))
        }
    }
}
