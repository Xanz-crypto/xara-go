package com.xara.go.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xara.go.model.InstalledGame
import com.xara.go.ui.theme.*

@Composable
fun TextureScreen(
    selectedGame: InstalledGame?,
    onBack: () -> Unit,
    onSaveTextureConfig: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textureDetailLevel by remember { mutableStateOf(3) } // 0=Asli, 1=Ringan, 2=Retro, 3=Kotak, 4=Ekstrem
    var isPixelSharp by remember { mutableStateOf(false) }
    var isDistanceLODSharp by remember { mutableStateOf(false) }
    var isGameTextureActive by remember { mutableStateOf(true) }
    var comparisonSplitRatio by remember { mutableStateOf(0.5f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Bar Atas Navigasi
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(PillInactive)
                    .clickable { onBack() }
                    .padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Kembali",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Text(
                    text = "XARA GAME SPACE",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp, color = NeonCyan)
                )
                Text(
                    text = "Tekstur Ringan",
                    style = MaterialTheme.typography.headlineMedium.copy(fontSize = 20.sp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Konten Utama
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Kolom Kiri: Visualisasi Perbandingan SEBELUM vs SESUDAH
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Preview Gambar Komparasi
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F172A))
                            .border(1.dp, Color(0x33334155), RoundedCornerShape(14.dp))
                    ) {
                        Row(modifier = Modifier.fillMaxSize()) {
                            // Sisi SEBELUM (Normal Texture)
                            Box(
                                modifier = Modifier
                                    .weight(comparisonSplitRatio)
                                    .fillMaxHeight()
                                    .background(Color(0xFF1E293B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "SEBELUM\n(Tekstur Penuh)",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                    modifier = Modifier.padding(8.dp)
                                )
                            }

                            // Garis Pembatas Slider
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .fillMaxHeight()
                                    .background(NeonCyan)
                            )

                            // Sisi SESUDAH (Optimized Minecraft-style low lod texture)
                            Box(
                                modifier = Modifier
                                    .weight(1f - comparisonSplitRatio)
                                    .fillMaxHeight()
                                    .background(Color(0xFF0F1E36)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "SESUDAH\n(Tekstur Ringan)",
                                    style = MaterialTheme.typography.labelSmall.copy(color = NeonCyan),
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Toggle Aktivasi Game
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(PillInactive)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = selectedGame?.appName ?: "Game",
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp)
                            )
                            Text(
                                text = "Aktifkan untuk ${selectedGame?.appName ?: "Game"}",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 10.sp)
                            )
                        }

                        Switch(
                            checked = isGameTextureActive,
                            onCheckedChange = { isGameTextureActive = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = DarkBgStart,
                                checkedTrackColor = NeonCyan
                            )
                        )
                    }
                }
            }

            // Kolom Kanan: PRESET CEPAT & SLIDER DETAIL
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceCard)
                    .border(1.dp, Color(0x2200E5FF), RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // PRESET CEPAT
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("PRESET CEPAT", style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Halus", "Retro", "Kotak Total", "Kustom").forEachIndexed { idx, name ->
                                val isSelected = (idx == 2 && textureDetailLevel == 3) || (idx == 3)

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isSelected) PillActive else PillInactive)
                                        .border(
                                            1.dp,
                                            if (isSelected) NeonCyan else Color.Transparent,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            if (idx == 0) textureDetailLevel = 1
                                            if (idx == 1) textureDetailLevel = 2
                                            if (idx == 2) textureDetailLevel = 3
                                        }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = name,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontSize = 11.sp,
                                            color = if (isSelected) NeonCyan else TextSecondary
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Slider Detail Tekstur
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Detail Tekstur", style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp))
                            val levels = listOf("Asli", "Ringan", "Retro", "Kotak", "Ekstrem")
                            Text(
                                text = levels.getOrElse(textureDetailLevel) { "Kotak" },
                                style = MaterialTheme.typography.titleMedium.copy(color = NeonCyan, fontSize = 12.sp)
                            )
                        }

                        Slider(
                            value = textureDetailLevel.toFloat(),
                            onValueChange = { textureDetailLevel = it.toInt() },
                            valueRange = 0f..4f,
                            steps = 3,
                            colors = SliderDefaults.colors(
                                thumbColor = NeonCyan,
                                activeTrackColor = NeonCyan,
                                inactiveTrackColor = Color(0xFF334155)
                            )
                        )
                    }

                    // Switches Piksel Tajam & Batas Jarak Tegas
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Piksel Tajam", style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp))
                                Text("Tepi tekstur kotak-kotak. Matikan untuk efek buram halus.", style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 9.sp))
                            }
                            Switch(
                                checked = isPixelSharp,
                                onCheckedChange = { isPixelSharp = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = DarkBgStart, checkedTrackColor = NeonCyan)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Batas Jarak Tegas", style = MaterialTheme.typography.titleMedium.copy(fontSize = 12.sp))
                                Text("Perpindahan detail dekat-jauh jadi patah-patah.", style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted, fontSize = 9.sp))
                            }
                            Switch(
                                checked = isDistanceLODSharp,
                                onCheckedChange = { isDistanceLODSharp = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = DarkBgStart, checkedTrackColor = NeonCyan)
                            )
                        }
                    }

                    // Tombol Aksi Bawah: Reset ke Asli + Simpan
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(PillInactive)
                                .clickable {
                                    textureDetailLevel = 0
                                    isPixelSharp = false
                                    isDistanceLODSharp = false
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                            Text("Reset ke Asli", style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp))
                        }

                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(NeonCyan)
                                .clickable { onSaveTextureConfig() }
                                .padding(horizontal = 20.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = DarkBgStart, modifier = Modifier.size(16.dp))
                            Text("Simpan", style = MaterialTheme.typography.titleMedium.copy(color = DarkBgStart, fontWeight = FontWeight.Bold, fontSize = 13.sp))
                        }
                    }
                }
            }
        }
    }
}
