package com.xara.go.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.xara.go.XaraGoApplication
import com.xara.go.model.GameManager
import kotlinx.coroutines.*

class GameWatcherService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private lateinit var gameManager: GameManager
    private var lastForegroundPackage: String? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        gameManager = GameManager(this)
        startForegroundNotification()
        startWatching()
    }

    private fun startForegroundNotification() {
        val channelId = "xara_watcher_channel"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Xara Game Watcher",
                NotificationManager.IMPORTANCE_LOW
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Xara Go Aktif Memantau Game")
            .setContentText("Otomatis mengoptimalkan RAM dan menutup aplikasi saat game dibuka.")
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun startWatching() {
        serviceScope.launch {
            val app = XaraGoApplication.instance
            while (isActive) {
                try {
                    val currentPkg = getForegroundPackage()
                    if (currentPkg != null && currentPkg != lastForegroundPackage && currentPkg != packageName) {
                        val installedGames = gameManager.getInstalledGames().map { it.packageName }
                        if (installedGames.contains(currentPkg)) {
                            // Game baru dibuka! Jalankan optimasi otomatis
                            lastForegroundPackage = currentPkg
                            gameManager.autoCleanForGameLaunch(app.shizukuManager)
                            app.hardwareMonitor.performRealRamClean()
                        }
                    }
                } catch (_: Exception) {}
                delay(2500)
            }
        }
    }

    private fun getForegroundPackage(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return null
        val time = System.currentTimeMillis()
        val events = usageStatsManager.queryEvents(time - 10000, time)
        val event = android.app.usage.UsageEvents.Event()
        var lastPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == android.app.usage.UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = event.packageName
            }
        }
        return lastPkg
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        private const val NOTIFICATION_ID = 2002

        fun start(context: Context) {
            val intent = Intent(context, GameWatcherService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
