package com.xara.go.model

import android.graphics.drawable.Drawable

data class InstalledGame(
    val packageName: String,
    val appName: String,
    val icon: Drawable? = null,
    val playedTimeMinutes: Long = 0,
    val isCustomMode: Boolean = true
)

data class BackgroundApp(
    val packageName: String,
    val appName: String,
    val memoryUsageMb: Int,
    val isSystem: Boolean,
    val isWhitelisted: Boolean,
    val icon: Drawable? = null
)
